import { useState, createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import type { Role, UserInfo } from '../data/mockData';
import { USERS } from '../data/mockData';

interface AppContextValue {
  currentUser: UserInfo;
  setCurrentUser: (u: UserInfo) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean) => void;
  activePage: string;
  setActivePage: (p: string) => void;
  notifications: number;
}

const AppContext = createContext<AppContextValue>({
  currentUser: USERS[0],
  setCurrentUser: () => {},
  sidebarCollapsed: false,
  setSidebarCollapsed: () => {},
  activePage: 'dashboard',
  setActivePage: () => {},
  notifications: 5,
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<UserInfo>(USERS[0]);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activePage, setActivePage] = useState('dashboard');

  return (
    <AppContext.Provider value={{
      currentUser,
      setCurrentUser,
      sidebarCollapsed,
      setSidebarCollapsed,
      activePage,
      setActivePage,
      notifications: 5,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}

export function hasPermission(role: Role, module: string): boolean {
  const perms: Record<Role, string[]> = {
    superadmin: ['dashboard', 'customers', 'orders', 'appointments', 'services', 'therapists', 'finance', 'accounts', 'reports', 'settings'],
    admin: ['dashboard', 'customers', 'orders', 'appointments', 'services', 'therapists', 'finance', 'reports', 'settings'],
    service: ['dashboard', 'customers', 'orders', 'appointments', 'services'],
    therapist: ['dashboard', 'appointments', 'services', 'profile', 'salary'],
    finance: ['dashboard', 'orders', 'finance'],
  };
  return (perms[role] ?? []).includes(module);
}
